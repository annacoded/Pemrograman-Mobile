package com.example.dreamstravel.data.remote
import kotlinx.serialization.Serializable

// Tambahkan @Serializable di semua data class yang berhubungan dengan API
@Serializable
data class CountryResponse(
    val name: Name?, // Jadikan nullable
    val flags: Flags?, // Jadikan nullable
    val region: String? // Jadikan nullable
)

@Serializable
data class Name(val common: String?)

@Serializable
data class Flags(val png: String?)