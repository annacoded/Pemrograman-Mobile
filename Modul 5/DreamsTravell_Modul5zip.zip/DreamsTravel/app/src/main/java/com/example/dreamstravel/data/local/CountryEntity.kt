package com.example.dreamstravel.data.local
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "country")
data class CountryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val nama: String?,
    val tahun: String,      // Bisa Anda hapus jika tidak digunakan, atau isi dengan data lain dari API
    val alasan: String,     // Diisi dengan 'region' dari API
    val imageUrl: String?,  // Ini yang akan kita gunakan untuk gambar
    val wikiUrl: String,
    val isFavorite: Boolean = false
)