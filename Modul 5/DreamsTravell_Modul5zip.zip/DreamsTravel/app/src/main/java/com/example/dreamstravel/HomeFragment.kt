package com.example.dreamstravel

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.net.toUri
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.dreamstravel.databinding.FragmentHomeBinding
import com.example.dreamstravel.viewmodel.CountryViewModel
import com.example.dreamstravel.viewmodel.CountryViewModelFactory
import kotlinx.coroutines.launch

class HomeFragment : Fragment() {
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    private val viewModel: CountryViewModel by activityViewModels {
        CountryViewModelFactory(
            requireActivity().application,
            (requireActivity().application as DreamsTravelApp).repository
        )
    }
    private lateinit var adapter: CountryAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()

        // Amati perubahan status UI dari ViewModel
        lifecycleScope.launch {
            // GANTI viewModel.listCountry MENJADI viewModel.listCountryState
            viewModel.listCountryState.collect { state ->
                // Gunakan 'when' untuk menangani setiap status
                when (state) {
                    is UiState.Loading -> {
                        binding.progressBar.isVisible = true
                        binding.rvNegara.isVisible = false
                        binding.tvError.isVisible = false
                    }
                    is UiState.Success -> {
                        binding.progressBar.isVisible = false
                        binding.rvNegara.isVisible = true
                        binding.tvError.isVisible = false
                        adapter.updateData(state.data)
                    }
                    is UiState.Error -> {
                        binding.progressBar.isVisible = false
                        binding.rvNegara.isVisible = false
                        binding.tvError.isVisible = true
                        binding.tvError.text = state.message
                    }
                }
            }
        }
    }

    private fun setupRecyclerView() {
        adapter = CountryAdapter(
            countries = emptyList(),
            onDetailClick = { country ->
                country.nama?.let { name ->
                    val action = HomeFragmentDirections.actionHomeFragmentToDetailFragment(name)
                    findNavController().navigate(action)
                }
            },
            onWikiClick = { country ->
                val intent = Intent(Intent.ACTION_VIEW, country.wikiUrl.toUri())
                startActivity(intent)
            },
            onFavoriteClick = { country ->
                viewModel.toggleFavorite(country)
            }
        )
        binding.rvNegara.layoutManager = LinearLayoutManager(requireContext())
        binding.rvNegara.adapter = adapter
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}