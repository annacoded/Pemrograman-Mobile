package com.example.dreamstravel.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow
import androidx.room.Update


@Dao
interface CountryDao {

    @Query("SELECT * FROM country")
    fun getAllCountries(): Flow<List<CountryEntity>>

    @Query("SELECT * FROM country WHERE nama = :name LIMIT 1")
    fun getCountryByName(name: String): Flow<CountryEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(countries: List<CountryEntity>)

    @Query("DELETE FROM country")
    suspend fun deleteAll()

    @Query("SELECT * FROM country WHERE isFavorite = 1 ORDER BY nama ASC")
    fun getFavoriteCountries(): Flow<List<CountryEntity>>

    @Update
    suspend fun updateCountry(country: CountryEntity)
}