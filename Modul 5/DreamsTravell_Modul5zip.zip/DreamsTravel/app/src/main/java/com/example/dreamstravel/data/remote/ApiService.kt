package com.example.dreamstravel.data.remote

import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService {
    @GET("all")
    suspend fun getAllCountries(
        @Query("fields") fields: String = "name,flags,region"
    ): List<CountryResponse>
}