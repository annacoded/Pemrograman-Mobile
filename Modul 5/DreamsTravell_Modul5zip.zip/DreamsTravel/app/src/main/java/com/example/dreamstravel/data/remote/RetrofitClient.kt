package com.example.dreamstravel.data.remote

import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit

@OptIn(ExperimentalSerializationApi::class)
object RetrofitClient {
    private val json = Json { ignoreUnknownKeys = true }

    // 1. Buat Logging Interceptor
    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY // BODY akan menampilkan semua detail
    }

    // 2. Buat OkHttpClient dan tambahkan interceptor
    private val client = OkHttpClient.Builder()
        .addInterceptor(loggingInterceptor)
        .build()

    // 3. Bangun Retrofit dengan OkHttpClient yang sudah kita buat
    val apiService: ApiService by lazy {
        Retrofit.Builder()
            .baseUrl("https://restcountries.com/v3.1/")
            .client(client) // <-- GUNAKAN CLIENT YANG SUDAH ADA INTERCEPTORNYA
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
            .create(ApiService::class.java)
    }
}