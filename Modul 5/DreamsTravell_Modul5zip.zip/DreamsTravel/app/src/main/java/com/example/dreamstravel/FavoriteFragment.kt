package com.example.dreamstravel

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.net.toUri
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.dreamstravel.databinding.FragmentFavoriteBinding
import com.example.dreamstravel.viewmodel.CountryViewModel
import com.example.dreamstravel.viewmodel.CountryViewModelFactory
import kotlinx.coroutines.launch

class FavoriteFragment : Fragment() {
    private var _binding: FragmentFavoriteBinding? = null
    private val binding get() = _binding!!

    private val viewModel: CountryViewModel by activityViewModels {
        CountryViewModelFactory(
            requireActivity().application,
            (requireActivity().application as DreamsTravelApp).repository
        )
    }
    private lateinit var adapter: CountryAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentFavoriteBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()

        // Panggil ViewModel untuk memuat daftar favorit
        viewModel.loadFavoriteCountries()

        // Amati perubahan pada daftar favorit
        lifecycleScope.launch {
            viewModel.favoriteListState.collect { state ->
                when (state) {
                    is UiState.Loading -> {
                        binding.progressBar.isVisible = true
                        binding.rvNegara.isVisible = false
                        binding.tvInfo.isVisible = false
                    }
                    is UiState.Success -> {
                        binding.progressBar.isVisible = false
                        // Tampilkan daftar jika tidak kosong, atau tampilkan pesan jika kosong
                        if (state.data.isEmpty()) {
                            binding.rvNegara.isVisible = false
                            binding.tvInfo.isVisible = true
                            binding.tvInfo.text = "Belum ada negara favorit"
                        } else {
                            binding.rvNegara.isVisible = true
                            binding.tvInfo.isVisible = false
                            adapter.updateData(state.data)
                        }
                    }
                    is UiState.Error -> {
                        binding.progressBar.isVisible = false
                        binding.rvNegara.isVisible = false
                        binding.tvInfo.isVisible = true
                        binding.tvInfo.text = state.message
                    }
                }
            }
        }
    }

    private fun setupRecyclerView() {
        adapter = CountryAdapter(
            countries = emptyList(),
            onDetailClick = { country ->
                // Navigasi dari Favorite ke Detail butuh action baru di nav_graph
                country.nama?.let { name ->
                    val action = FavoriteFragmentDirections.actionFavoriteFragmentToDetailFragment(name)
                    findNavController().navigate(action)
                }
            },
            onWikiClick = { country ->
                val intent = Intent(Intent.ACTION_VIEW, country.wikiUrl.toUri())
                startActivity(intent)
            },
            onFavoriteClick = { country ->
                // Tetap panggil fungsi yang sama
                viewModel.toggleFavorite(country)
            }
        )
        binding.rvNegara.layoutManager = LinearLayoutManager(requireContext())
        binding.rvNegara.adapter = adapter
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}