package com.example.dreamstravel

import android.app.Application
import com.example.dreamstravel.data.local.CountryRepository
import com.example.dreamstravel.data.local.CountryDatabase

class DreamsTravelApp : Application() {
    // Inisialisasi database dan repository
    val database by lazy { CountryDatabase.getInstance(this) }
    val repository by lazy { CountryRepository(database.countryDao()) }
}
