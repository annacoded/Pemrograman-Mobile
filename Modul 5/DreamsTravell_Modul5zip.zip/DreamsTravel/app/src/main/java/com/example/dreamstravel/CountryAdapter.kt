package com.example.dreamstravel

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.dreamstravel.data.local.CountryEntity
import com.example.dreamstravel.databinding.ItemNegaraBinding

class CountryAdapter(
    private var countries: List<CountryEntity>,
    private val onDetailClick: (CountryEntity) -> Unit,
    private val onWikiClick: (CountryEntity) -> Unit,
    private val onFavoriteClick: (CountryEntity) -> Unit
) : RecyclerView.Adapter<CountryAdapter.CountryViewHolder>() {

    inner class CountryViewHolder(val binding: ItemNegaraBinding) : RecyclerView.ViewHolder(binding.root)
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CountryViewHolder {
        val binding = ItemNegaraBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CountryViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CountryViewHolder, position: Int) {
        val country = countries[position]
        with(holder.binding) {
            tvItemName.text = country.nama
            tvAlasan.text = country.alasan // Menampilkan region

            // Gunakan Coil untuk memuat gambar dari URL
            imgItemPhoto.load(country.imageUrl) {
                placeholder(R.drawable.ic_launcher_background)
                error(R.drawable.ic_launcher_foreground)
            }

            buttonDetail.setOnClickListener { onDetailClick(country) }
            btnWiki.setOnClickListener { onWikiClick(country) }

            btnFavorite.setImageResource(
                if (country.isFavorite) R.drawable.ic_favorite
                else R.drawable.ic_favorite_border
            )
            btnFavorite.setOnClickListener { onFavoriteClick(country) }
        }
    }

    override fun getItemCount(): Int = countries.size

    @SuppressLint("NotifyDataSetChanged")
    fun updateData(newList: List<CountryEntity>) {
        countries = newList
        notifyDataSetChanged()
    }
}