package com.example.dreamstravel.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.dreamstravel.UiState
import com.example.dreamstravel.data.local.CountryEntity
import com.example.dreamstravel.data.local.CountryRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.io.IOException

class CountryViewModel(
    application: Application,
    private val repository: CountryRepository
) : AndroidViewModel(application) {

    private val _listCountryState = MutableStateFlow<UiState<List<CountryEntity>>>(UiState.Loading)
    val listCountryState: StateFlow<UiState<List<CountryEntity>>> get() = _listCountryState

    // StateFlow untuk halaman Favorit
    private val _favoriteListState = MutableStateFlow<UiState<List<CountryEntity>>>(UiState.Loading)
    val favoriteListState: StateFlow<UiState<List<CountryEntity>>> get() = _favoriteListState

    // StateFlow untuk halaman Detail
    private val _countryDetail = MutableStateFlow<CountryEntity?>(null)
    val countryDetail: StateFlow<CountryEntity?> get() = _countryDetail

    init {
        loadCountries()
    }

    fun loadCountries() {
        _listCountryState.value = UiState.Loading
        viewModelScope.launch {
            try {

                val remoteData = repository.fetchCountriesFromApi()
                repository.insertAll(remoteData) // Simpan/Update ke database

                repository.getAllCountries().collect { countries ->
                    _listCountryState.value = UiState.Success(countries)
                }
            } catch (e: IOException) {
                _listCountryState.value = UiState.Error("Gagal terhubung ke server. Periksa koneksi internet.")
            } catch (e: Exception) {
                _listCountryState.value = UiState.Error("Terjadi kesalahan: ${e.message}")
            }
        }
    }
    fun loadFavoriteCountries() {
        _favoriteListState.value = UiState.Loading
        viewModelScope.launch {
            try {
                repository.getFavoriteCountries().collect { favorites ->
                    _favoriteListState.value = UiState.Success(favorites)
                }
            } catch (e: Exception) {
                _favoriteListState.value = UiState.Error("Gagal memuat daftar favorit: ${e.message}")
            }
        }
    }

    fun loadCountryByName(countryName: String) {
        viewModelScope.launch {
            repository.getCountryByName(countryName).collect { country ->
                _countryDetail.value = country
            }
        }
    }

    fun toggleFavorite(country: CountryEntity) {
        viewModelScope.launch {
            val updated = country.copy(isFavorite = !country.isFavorite)
            repository.updateCountry(updated)

            if (_favoriteListState.value is UiState.Success) {
                loadFavoriteCountries()
            }
        }
    }
}