package com.example.dreamstravel.data.local

import com.example.dreamstravel.data.remote.CountryResponse
import com.example.dreamstravel.data.remote.RetrofitClient
import kotlinx.coroutines.flow.Flow

class CountryRepository(private val countryDao: CountryDao) {

    fun getAllCountries(): Flow<List<CountryEntity>> {
        return countryDao.getAllCountries()
    }

    fun getCountryByName(name: String): Flow<CountryEntity?> { // Pastikan return type bisa null
        return countryDao.getCountryByName(name)
    }

    suspend fun insertAll(countries: List<CountryEntity>) {
        countryDao.insertAll(countries)
    }

    suspend fun updateCountry(country: CountryEntity) {
        countryDao.updateCountry(country)
    }

    fun getFavoriteCountries(): Flow<List<CountryEntity>> {
        return countryDao.getFavoriteCountries()
    }

    suspend fun fetchCountriesFromApi(): List<CountryEntity> {
        val response: List<CountryResponse> = RetrofitClient.apiService.getAllCountries()

        // Ganti 'map' menjadi 'mapNotNull' untuk secara otomatis memfilter hasil yang null
        return response.mapNotNull { countryResponse ->
            // Gunakan ?. untuk mengakses properti dari objek yang bisa null
            val countryName = countryResponse.name?.common
            val flagUrl = countryResponse.flags?.png
            val region = countryResponse.region

            // Jika nama atau URL bendera tidak ada, lewati item ini (return null)
            if (countryName.isNullOrEmpty() || flagUrl.isNullOrEmpty()) {
                null
            } else {
                CountryEntity(
                    nama = countryName,
                    tahun = "2025", // Data statis atau bisa diambil dari field lain jika ada
                    alasan = region ?: "No region", // Memberikan nilai default jika region null
                    imageUrl = flagUrl,
                    wikiUrl = "https://en.wikipedia.org/wiki/${countryName.replace(" ", "_")}"
                )
            }
        }
    }
}