package com.example.dreamstravel

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.navArgs
import coil.load
import com.example.dreamstravel.databinding.FragmentDetailBinding
import com.example.dreamstravel.viewmodel.CountryViewModel
import com.example.dreamstravel.viewmodel.CountryViewModelFactory
import kotlinx.coroutines.launch

class DetailFragment : Fragment() {

    private var _binding: FragmentDetailBinding? = null
    private val binding get() = _binding!!

    private val args: DetailFragmentArgs by navArgs()

    private val viewModel: CountryViewModel by activityViewModels {
        CountryViewModelFactory(
            requireActivity().application,
            (requireActivity().application as DreamsTravelApp).repository
        )
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Tampilkan loading indicator
        binding.progressBar.visibility = View.VISIBLE
        binding.contentGroup.visibility = View.GONE

        // Minta ViewModel untuk memuat data detail berdasarkan nama
        viewModel.loadCountryByName(args.name)

        // Amati perubahan pada data detail
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.countryDetail.collect { country ->
                // Sembunyikan loading indicator setelah data (atau null) diterima
                binding.progressBar.visibility = View.GONE

                country?.let {
                    // Tampilkan konten jika data ada
                    binding.contentGroup.visibility = View.VISIBLE
                    binding.tvDetailName.text = it.nama
                    binding.tvDetailAlasan.text = it.alasan

                    // Gunakan Coil untuk memuat gambar dari URL
                    binding.imgDetailPhoto.load(it.imageUrl) {
                        placeholder(R.drawable.ic_launcher_background)
                        error(R.drawable.ic_launcher_foreground)
                    }
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}