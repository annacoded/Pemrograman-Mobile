package com.example.tipcalc

import android.os.Bundle
import androidx.activity.ComponentActivity
import android.widget.Toast
import com.example.tipcalc.databinding.ActivityMainBinding


class MainActivity : ComponentActivity() {

    lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.calculate.setOnClickListener {
            hitung()
        }
    }
    private fun hitung(){
        val cost = binding.costOfService.text.toString().toDouble()
        val tip = binding.tipOptions.checkedRadioButtonId
        val tipPercent = when (tip) {
            R.id.option_twenty -> 0.20
            R.id.option_eighteen -> 0.18
            else -> 0.15
        }

        var total = tipPercent * cost
        val roundUp = binding.roundUp.isChecked
        if(roundUp){
            total = kotlin.math.ceil(total)
        }
        if(cost <= 0){
            Toast.makeText(this, "Masukkan angka yang valid", Toast.LENGTH_SHORT).show()
        }else{
            binding.total.text = total.toString()
        }
    }
}