package com.example.ambildataapi

import android.annotation.SuppressLint
import com.example.ambildataapi.R
import android.os.Bundle
import android.view.View
import androidx.activity.ComponentActivity
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.ambildataapi.ui.theme.AmbilDataAPITheme
import okhttp3.*
import java.io.IOException
import android.widget.TextView
import android.widget.Button


class MainActivity : ComponentActivity() {

    private lateinit var hasilTextView: TextView
    private lateinit var btnAmbilData: Button
    private lateinit var btnKembali: Button

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        hasilTextView = findViewById(R.id.hasilTextView)
        btnAmbilData = findViewById(R.id.btnAmbilData)
        btnKembali = findViewById(R.id.btnKembali)

        btnAmbilData.setOnClickListener {
            ambilDataDariAPI()
            btnAmbilData.visibility = View.GONE
            btnKembali.visibility = View.VISIBLE
        }

        btnKembali.setOnClickListener {
            hasilTextView.text = ""
            btnAmbilData.visibility = View.VISIBLE
            btnKembali.visibility = View.GONE
        }
    } 

    private fun ambilDataDariAPI() {
        val client = OkHttpClient()
        val url = "https://latihanmobile2.free.beeceptor.com/data"

        val request = Request.Builder().url(url).build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread { hasilTextView.text = "Gagal: ${e.message}" }
            }

            override fun onResponse(call: Call, response: Response) {
                val responseData = response.body?.string() ?: "Response kosong"
                runOnUiThread { hasilTextView.text = responseData }
            }
        })
    }
}

    @Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    AmbilDataAPITheme {
        Greeting("Android")
    }
}


