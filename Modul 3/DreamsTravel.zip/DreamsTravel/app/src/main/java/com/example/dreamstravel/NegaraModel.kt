package com.example.dreamstravel


data class NegaraModel(
    val nama: String,
    val tahun: String,
    val alasan: String,
    val gambarResId: Int,
    val wikiUrl: String
)