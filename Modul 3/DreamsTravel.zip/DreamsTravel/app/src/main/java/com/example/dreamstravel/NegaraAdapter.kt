package com.example.dreamstravel

import android.content.Intent
import androidx.core.net.toUri
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.navigation.NavController
import androidx.recyclerview.widget.RecyclerView
import com.example.dreamstravel.databinding.ItemNegaraBinding

class NegaraAdapter(
    private val listNegara: List<NegaraModel>,
    private val navController: NavController
) : RecyclerView.Adapter<NegaraAdapter.NegaraViewHolder>() {

    inner class NegaraViewHolder(val binding: ItemNegaraBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NegaraViewHolder {
        val binding = ItemNegaraBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return NegaraViewHolder(binding)
    }

    override fun onBindViewHolder(holder: NegaraViewHolder, position: Int) {
        val negara = listNegara[position]
        holder.binding.tvItemName.text = negara.nama
        holder.binding.imgItemPhoto.setImageResource(negara.gambarResId)
        holder.binding.btnWiki.setOnClickListener{
            var url = negara.wikiUrl
            val intent = Intent(Intent.ACTION_VIEW, url.toUri())
            it.context.startActivity(intent)
        }

        holder.binding.buttonDetail.setOnClickListener {
            val bundle = android.os.Bundle().apply {
                putInt("gambarResId", negara.gambarResId)
                putString("namaNegara", negara.nama)
                putString("alasan", negara.alasan)
            }
            navController.navigate(R.id.detailFragment, bundle)
        }
    }
    override fun getItemCount() = listNegara.size
}
