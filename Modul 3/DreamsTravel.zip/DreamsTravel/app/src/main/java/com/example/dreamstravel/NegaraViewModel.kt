package com.example.dreamstravel
import android.app.Application
import androidx.lifecycle.AndroidViewModel
class NegaraViewModel(application: Application) : AndroidViewModel(application) {
    private val context = getApplication<Application>().applicationContext


    fun loadNegara(): List<NegaraModel> {
        val namaNegara = context.resources.getStringArray(R.array.list_negara)
        val tahun = context.resources.getStringArray(R.array.list_tahun)
        val alasan = context.resources.getStringArray(R.array.list_alasan)
        val link = context.resources.getStringArray(R.array.list_link)
        val gambar = listOf(
            R.drawable.japan,
            R.drawable.swiss,
            R.drawable.korsel,
            R.drawable.arabsaudi,
            R.drawable.france
        )

        return namaNegara.indices.map { i ->
            NegaraModel(
                namaNegara[i],
                tahun[i],
                alasan[i],
                gambar[i],
                link[i]
            )
        }
    }
}