package com.example.dreamstravel

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.dreamstravel.databinding.FragmentDetailBinding

class DetailFragment : Fragment() {

    private var _binding: FragmentDetailBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val namaNegara = arguments?.getString("namaNegara") ?: "Tidak ada nama"
        val alasan = arguments?.getString("alasan") ?: "Tidak ada tahun"
        val gambar = arguments?.getInt("gambarResId") ?: R.drawable.japan

        binding.imgCountry.setImageResource(gambar)
        binding.tvCountryName.text = namaNegara
        binding.tvCountryReason.text = alasan
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}