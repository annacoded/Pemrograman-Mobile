package com.example.dreamstravel

import NegaraViewModel
import NegaraViewModelFactory
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.dreamstravel.databinding.FragmentHomeBinding
import kotlinx.coroutines.launch
import androidx.core.net.toUri
import androidx.navigation.fragment.findNavController

class HomeFragment : Fragment() {
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    private lateinit var viewModel: NegaraViewModel
    private lateinit var adapter: NegaraAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        // Gunakan ViewModelFactory
        val factory = NegaraViewModelFactory(requireActivity().application)
        viewModel = ViewModelProvider(this, factory)[NegaraViewModel::class.java]

        // Setup Adapter tanpa navController, dengan dua callback
        adapter = NegaraAdapter(
            listNegara = emptyList(),
            onDetailClick = { negara ->
                Log.d("HomeFragment", "Tombol Detail ditekan: ${negara.nama}")
                viewModel.onItemClicked(negara)

                val bundle = Bundle().apply {
                    putInt("gambarResId", negara.gambarResId)
                    putString("namaNegara", negara.nama)
                    putString("alasan", negara.alasan)
                }

                Log.d("HomeFragment", "Navigasi ke detail dengan: ${negara.nama}")
                findNavController().navigate(R.id.detailFragment, bundle)
            },
            onWikiClick = { negara ->
                Log.d("HomeFragment", "Tombol Wiki ditekan: ${negara.nama}")
                val intent = Intent(Intent.ACTION_VIEW, negara.wikiUrl.toUri())
                startActivity(intent)
            }
        )

        binding.rvNegara.layoutManager = LinearLayoutManager(requireContext())
        binding.rvNegara.adapter = adapter

        // Observe StateFlow dari ViewModel
        lifecycleScope.launch {
            viewModel.listNegara.collect { negaraList ->
                Log.d("HomeFragment", "Data listNegara masuk (${negaraList.size} item)")
                adapter.updateData(negaraList)
            }
        }

        // Panggil loadNegara agar data dimuat
        viewModel.loadNegara()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
