import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import com.example.dreamstravel.NegaraModel
import com.example.dreamstravel.R

class NegaraViewModel(application: Application) : AndroidViewModel(application) {

    private val context = getApplication<Application>().applicationContext

    private val _listNegara = MutableStateFlow<List<NegaraModel>>(emptyList())
    val listNegara: StateFlow<List<NegaraModel>> get() = _listNegara

    private val _selectedNegara = MutableStateFlow<NegaraModel?>(null)
    val selectedNegara: StateFlow<NegaraModel?> get() = _selectedNegara

    fun loadNegara() {
        viewModelScope.launch {
            val namaNegara = context.resources.getStringArray(R.array.list_negara)
            val tahun = context.resources.getStringArray(R.array.list_tahun)
            val alasan = context.resources.getStringArray(R.array.list_alasan)
            val link = context.resources.getStringArray(R.array.list_link)
            val gambar = listOf(
                R.drawable.japan,
                R.drawable.swiss,
                R.drawable.korsel,
                R.drawable.arabsaudi,
                R.drawable.france
            )

            val negaraList = namaNegara.indices.map { i ->
                NegaraModel(
                    namaNegara[i],
                    tahun[i],
                    alasan[i],
                    gambar[i],
                    link[i]
                )
            }

            _listNegara.value = negaraList
            Log.d("NegaraViewModel", "List negara dimuat: ${negaraList.size} item")
        }
    }

    fun onItemClicked(negara: NegaraModel) {
        _selectedNegara.value = negara
        Log.d("NegaraViewModel", "Negara dipilih: ${negara.nama}")
    }
}
