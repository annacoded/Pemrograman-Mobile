package com.example.dreamstravel

import android.content.Intent
import androidx.core.net.toUri
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.dreamstravel.databinding.ItemNegaraBinding

class NegaraAdapter(
    private var listNegara: List<NegaraModel>,
    private val onDetailClick: (NegaraModel) -> Unit,
    private val onWikiClick: (NegaraModel) -> Unit
) : RecyclerView.Adapter<NegaraAdapter.NegaraViewHolder>() {

    inner class NegaraViewHolder(val binding: ItemNegaraBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NegaraViewHolder {
        val binding = ItemNegaraBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return NegaraViewHolder(binding)
    }

    override fun onBindViewHolder(holder: NegaraViewHolder, position: Int) {
        val negara = listNegara[position]
        holder.binding.tvItemName.text = negara.nama
        holder.binding.imgItemPhoto.setImageResource(negara.gambarResId)

        holder.binding.btnWiki.setOnClickListener {
            onWikiClick(negara)
        }

        holder.binding.buttonDetail.setOnClickListener {
            onDetailClick(negara)
        }
    }

    override fun getItemCount() = listNegara.size

    fun updateData(newList: List<NegaraModel>) {
        listNegara = newList
        notifyDataSetChanged()
    }
}
